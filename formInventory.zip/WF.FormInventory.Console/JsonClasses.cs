﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace WF.FormInventory.CLI
{
    // Root myDeserializedClass = JsonSerializer.Deserialize<Root>(myJsonResponse);
    public class Configuration
    {
        [JsonPropertyName("FormElementGuid")]
        public string FormElementGuid { get; set; }

        [JsonPropertyName("FormElementConfigurationGuid")]
        public string FormElementConfigurationGuid { get; set; }

        [JsonPropertyName("Value")]
        public string Value { get; set; }

        [JsonPropertyName("FormElementConfigurationName")]
        public string FormElementConfigurationName { get; set; }

        [JsonPropertyName("EditorName")]
        public string EditorName { get; set; }

        [JsonPropertyName("IsCustomEditor")]
        public bool IsCustomEditor { get; set; }

        [JsonPropertyName("HelpText")]
        public object HelpText { get; set; }

        [JsonPropertyName("IsRequired")]
        public bool IsRequired { get; set; }

        [JsonPropertyName("DefaultValue")]
        public string DefaultValue { get; set; }

        [JsonPropertyName("AvailableConfigurationValues")]
        public string AvailableConfigurationValues { get; set; }
    }

    public class ChildElement
    {
        [JsonPropertyName("FormElementGuid")]
        public string FormElementGuid { get; set; }

        [JsonPropertyName("FormGuid")]
        public string FormGuid { get; set; }

        [JsonPropertyName("ParentFormElementGuid")]
        public string ParentFormElementGuid { get; set; }

        [JsonPropertyName("DisplayText")]
        public string DisplayText { get; set; }

        [JsonPropertyName("DisplayPosition")]
        public int DisplayPosition { get; set; }

        [JsonPropertyName("InputTypeId")]
        public int InputTypeId { get; set; }

        [JsonPropertyName("InputTypeName")]
        public string InputTypeName { get; set; }

        [JsonPropertyName("Configurations")]
        public List<Configuration> Configurations { get; set; }

        [JsonPropertyName("ChildElements")]
        public List<object> ChildElements { get; set; }
    }

    public class FormElement
    {
        [JsonPropertyName("FormElementGuid")]
        public string FormElementGuid { get; set; }

        [JsonPropertyName("FormGuid")]
        public string FormGuid { get; set; }

        [JsonPropertyName("ParentFormElementGuid")]
        public object ParentFormElementGuid { get; set; }

        [JsonPropertyName("DisplayText")]
        public string DisplayText { get; set; }

        [JsonPropertyName("DisplayPosition")]
        public int DisplayPosition { get; set; }

        [JsonPropertyName("InputTypeId")]
        public int InputTypeId { get; set; }

        [JsonPropertyName("InputTypeName")]
        public string InputTypeName { get; set; }

        [JsonPropertyName("Configurations")]
        public List<Configuration> Configurations { get; set; }

        [JsonPropertyName("ChildElements")]
        public List<ChildElement> ChildElements { get; set; }
    }

    public class ServiceRequestItemAttributeFormElement
    {
        [JsonPropertyName("ServiceRequestItemAttributeGuid")]
        public string ServiceRequestItemAttributeGuid { get; set; }

        [JsonPropertyName("FormElementGuid")]
        public string FormElementGuid { get; set; }

        [JsonPropertyName("DisplayPosition")]
        public int DisplayPosition { get; set; }
    }

    public class ServiceRequestItemAttribute
    {
        [JsonPropertyName("ServiceRequestItemAttributeGuid")]
        public string ServiceRequestItemAttributeGuid { get; set; }

        [JsonPropertyName("ServiceRequestItemGuid")]
        public string ServiceRequestItemGuid { get; set; }

        [JsonPropertyName("DisplayText")]
        public string DisplayText { get; set; }

        [JsonPropertyName("DisplayPosition")]
        public int DisplayPosition { get; set; }

        [JsonPropertyName("IsProvisioned")]
        public bool IsProvisioned { get; set; }

        [JsonPropertyName("PromptText")]
        public string PromptText { get; set; }

        [JsonPropertyName("FormatText")]
        public string FormatText { get; set; }

        [JsonPropertyName("ServiceRequestItemAttributeFormElements")]
        public List<ServiceRequestItemAttributeFormElement> ServiceRequestItemAttributeFormElements { get; set; }
    }

    public class ServiceRequestItem
    {
        [JsonPropertyName("ServiceRequestItemGuid")]
        public string ServiceRequestItemGuid { get; set; }

        [JsonPropertyName("FormGuid")]
        public string FormGuid { get; set; }

        [JsonPropertyName("ServiceRequestItemTypeId")]
        public int ServiceRequestItemTypeId { get; set; }

        [JsonPropertyName("ServiceRequestItemActionId")]
        public int ServiceRequestItemActionId { get; set; }

        [JsonPropertyName("DisplayText")]
        public string DisplayText { get; set; }

        [JsonPropertyName("DisplayPosition")]
        public int DisplayPosition { get; set; }

        [JsonPropertyName("Platform")]
        public string Platform { get; set; }

        [JsonPropertyName("Location")]
        public string Location { get; set; }

        [JsonPropertyName("Type")]
        public string Type { get; set; }

        [JsonPropertyName("UidFormElementGuid")]
        public string UidFormElementGuid { get; set; }

        [JsonPropertyName("ServiceRequestItemAttributes")]
        public List<ServiceRequestItemAttribute> ServiceRequestItemAttributes { get; set; }

        [JsonPropertyName("FormElementGuids")]
        public List<string> FormElementGuids { get; set; }

        [JsonPropertyName("BusinessRuleCodes")]
        public List<object> BusinessRuleCodes { get; set; }
    }

    public class Form
    {
        [JsonPropertyName("FormGuid")]
        public string FormGuid { get; set; }

        [JsonPropertyName("FormDirectoryGuid")]
        public string FormDirectoryGuid { get; set; }

        [JsonPropertyName("FormTypeId")]
        public int FormTypeId { get; set; }

        [JsonPropertyName("PlatformId")]
        public int PlatformId { get; set; }

        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("Title")]
        public string Title { get; set; }

        [JsonPropertyName("DisplayText")]
        public string DisplayText { get; set; }

        [JsonPropertyName("Description")]
        public string Description { get; set; }

        [JsonPropertyName("StringAppropriationElement")]
        public string StringAppropriationElement { get; set; }

        [JsonPropertyName("ExternalProcessor")]
        public string ExternalProcessor { get; set; }

        [JsonPropertyName("FormElements")]
        public List<FormElement> FormElements { get; set; }

        [JsonPropertyName("ServiceRequestItems")]
        public List<ServiceRequestItem> ServiceRequestItems { get; set; }

        [JsonPropertyName("DisplayLinking")]
        public object DisplayLinking { get; set; }

        [JsonPropertyName("UserPropLinkings")]
        public object UserPropLinkings { get; set; }
    }

    public class Value
    {
        [JsonPropertyName("DataValueID")]
        public int DataValueID { get; set; }

        [JsonPropertyName("DataSetID")]
        public int DataSetID { get; set; }

        [JsonPropertyName("Text")]
        public string Text { get; set; }

        [JsonPropertyName("Value")]
        public string ValueProperty { get; set; }

        [JsonPropertyName("SortOrder")]
        public int SortOrder { get; set; }
    }

    public class DataSet
    {
        [JsonPropertyName("DataSetID")]
        public int DataSetID { get; set; }

        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("CurrentVersion")]
        public int CurrentVersion { get; set; }

        [JsonPropertyName("IsActive")]
        public bool IsActive { get; set; }

        [JsonPropertyName("Values")]
        public List<Value> Values { get; set; }
    }

    public class DataLinking
    {
        [JsonPropertyName("DataValueLinkingID")]
        public int DataValueLinkingID { get; set; }

        [JsonPropertyName("LinkageType")]
        public string LinkageType { get; set; }

        [JsonPropertyName("MatchText")]
        public bool MatchText { get; set; }

        [JsonPropertyName("SourceFormElementGuid")]
        public string SourceFormElementGuid { get; set; }

        [JsonPropertyName("SelectedValue")]
        public string SelectedValue { get; set; }

        [JsonPropertyName("TargetFormElementGuid")]
        public string TargetFormElementGuid { get; set; }

        [JsonPropertyName("TargetValue")]
        public object TargetValue { get; set; }
    }

    public class FormBuilderRoot
    {
        [JsonPropertyName("Version")]
        public string Version { get; set; }

        [JsonPropertyName("ExportedBy")]
        public string ExportedBy { get; set; }

        [JsonPropertyName("ExportedUtcDateTime")]
        public DateTime ExportedUtcDateTime { get; set; }

        [JsonPropertyName("ExportedFrom")]
        public object ExportedFrom { get; set; }

        [JsonPropertyName("Form")]
        public Form Form { get; set; }

        [JsonPropertyName("DataSets")]
        public List<DataSet> DataSets { get; set; }

        [JsonPropertyName("DataLinkings")]
        public List<DataLinking> DataLinkings { get; set; }

        [JsonPropertyName("UserLinkings")]
        public List<object> UserLinkings { get; set; }
    }




}
