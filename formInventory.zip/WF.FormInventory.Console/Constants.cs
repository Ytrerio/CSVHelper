﻿namespace WF.FormInventory.CLI
{
    public static class Constants 
    {
        public const string FBX_DIR = @"TODO:put the right file path here!";
        public const string FBX_FILE_EXTENSION = "fbx";
        public const string JSON_DATA_FILENAME = "Form.xml";
        public const string FORMS_CSV_FILEPATH = "formsInventory.csv";
        public const string FORM_ELEMENTS_CSV_FILEPATH = "formElementsInventory.csv";
        public const string SERVICE_REQUESTS_CSV_FILEPATH = "serviceRequestsInventory.csv";
    }
}
