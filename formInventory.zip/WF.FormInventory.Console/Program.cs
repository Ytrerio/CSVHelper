﻿using CsvHelper;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace WF.FormInventory.CLI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Extracting data from {Constants.FBX_DIR}...");
            List<FormBuilderRoot> allForms = new List<FormBuilderRoot>();

            foreach (string file in Directory.EnumerateFiles(Constants.FBX_DIR, $"*.{Constants.FBX_FILE_EXTENSION}", SearchOption.AllDirectories))
            {
                using (FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                {
                    using (ZipArchive archive = new ZipArchive(fileStream, ZipArchiveMode.Read))
                    {
                        ZipArchiveEntry jsonDataFile = archive.Entries.Single(e => e.FullName.Equals(Constants.JSON_DATA_FILENAME));
                        FormBuilderRoot form;
                        using (var stream = jsonDataFile.Open())
                        using (var reader = new StreamReader(stream))
                        {
                            form = JsonSerializer.Deserialize<FormBuilderRoot>(reader.ReadToEnd());
                            allForms.Add(form);
                        }
                        if (form == null)
                            Console.WriteLine("Could not read form data...");
                        else
                            Console.WriteLine($"Found for {form.Form.Name} using platform {form.Form.PlatformId} in file {jsonDataFile.FullName}");
                    }
                }
            }

            var allFormsArray = allForms.ToArray();
            ICsvUtilities csvUtilities = new CsvHelperCsvUtilities();
            csvUtilities.CreateFormsCsvText(allFormsArray);
            csvUtilities.CreateFormElementsCsvText(allFormsArray);
            csvUtilities.CreateServiceRequestItemsCsvText(allFormsArray);

            Console.WriteLine("Done");
            Console.Read();
        }
    }

    internal class CsvHelperCsvUtilities : ICsvUtilities
    {
        public void CreateServiceRequestItemsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating service requiest items CSV data");
            using (var writer = new StreamWriter(Constants.SERVICE_REQUESTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<ServiceRequestItemMap>();
                csv.WriteRecords(formJson.SelectMany(f => f.Form.ServiceRequestItems));
            }
        }

        public void CreateFormElementsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating form elements CSV data");
            using (var writer = new StreamWriter(Constants.FORM_ELEMENTS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<FormElementMap>();
                csv.WriteRecords(formJson.SelectMany(f => f.Form.FormElements));
            }
        }

        public void CreateFormsCsvText(FormBuilderRoot[] formJson)
        {
            Console.WriteLine("Generating forms CSV data");
            using (var writer = new StreamWriter(Constants.FORMS_CSV_FILEPATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.Context.RegisterClassMap<FormMap>();
                csv.WriteRecords(formJson.Select(f => f.Form));
            }
        }
    }

    public class FormElementMap : ClassMap<FormElement>
    {
        public FormElementMap()
        {
            Map(m => m.InputTypeName).Index(0).Name("Input Type Name");
            Map(m => m.DisplayText).Index(1).Name("Display Text");
            Map(m => m.FormGuid).Index(2).Name("Form ID");
        }
    }

    public class ServiceRequestItemMap : ClassMap<ServiceRequestItem>
    {
        public ServiceRequestItemMap()
        {
            Map(m => m.ServiceRequestItemGuid).Index(0).Name("ID");
            Map(m => m.DisplayText).Index(1).Name("Type ID");
            Map(m => m.FormGuid).Index(2).Name("Form ID");
        }
    }

    public class FormMap : ClassMap<Form>
    {
        public FormMap()
        {
            Map(m => m.FormGuid).Index(0).Name("ID");
            Map(m => m.Name).Index(1).Name("Name");
            Map(m => m.FormTypeId).Index(2).Name("Form Type Id");
            Map(m => m.PlatformId).Index(3).Name("Platform Id");
        }
    }
}
